﻿# HD Extension for Revit

## Installation

1. Copy the entire HD.extension folder to your pyRevit extensions folder:
   - Default: %APPDATA%\pyRevit-Master\extensions\
   - Or custom location configured in pyRevit settings

2. Reload pyRevit or restart Revit

## Requirements

- Revit 2025 or 2026
- pyRevit 4.8+ (with IronPython or CPython 3)

## Tools Included

- **CommonFeature**: Element information, isolate, section box
- **CheckCode**: Code checking utilities

## Support

Contact: [Your contact info]
Version: 1.0.0

---
(c) 2026 - All rights reserved
